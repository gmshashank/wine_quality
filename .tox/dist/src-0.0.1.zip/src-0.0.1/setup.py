from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="Wine qualtiy classification package",
    author="gmshashank",
    packages=find_packages(),
    license="MIT",
)
